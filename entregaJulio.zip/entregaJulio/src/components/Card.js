import Produtos from "./Produtos"
import { StyledCard } from "./estilos/Card.style";
function Card(){
    return(
        <StyledCard>
            <Produtos />
        </StyledCard>

    )

}

export default Card;