import styled from 'styled-components'

export const Header = styled.div`

    display: flex;
    align-items: center;
    justify-content: left;
    background-color: #489e;
    height: 110px;
    
    & h1{
        color: white;
        margin-right:100px;
        font-size: 2em;
    }

    & img{
        width: 5em;
        
        float: left;
        padding: 2em;
    }
    
`
