import styled from 'styled-components'

export const StyledCard = styled.ul`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
    padding: 10px;
    border-radius: 5px;
    background-color: #f3f3f3;
`